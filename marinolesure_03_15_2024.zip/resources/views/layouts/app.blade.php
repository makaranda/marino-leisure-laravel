    @include('components.header')

    @include('components.nav')

    @yield('content')

    @include('components.footer')


