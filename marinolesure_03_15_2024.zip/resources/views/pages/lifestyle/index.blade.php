
@extends('layouts.app')


@section('content')

    <!-- Main Content -->
  
  

    <!-- Main Content -->
@endsection

@push('css')
    <style>
        .stu-manage-button-area{
            margin-top:50px;
            text-align: center;
        }
    </style>

@endpush

