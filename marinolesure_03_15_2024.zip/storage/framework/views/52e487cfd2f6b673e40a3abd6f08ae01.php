
    <!DOCTYPE html>
    <html lang="en">
    <head>

        <?php echo $__env->make('components.tags', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <meta charset="UTF-8"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Labookele Vila | Bungalow</title>
        <link rel="icon" href="<?php echo e(URL::to('')); ?>/resources/images/favicon.png" type="image/png">
        <meta name="keywords" content="Hotels,  Bungalow in Sri Lanka">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <?php echo $__env->make('libraries.styles', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </head>
    <body class="home">
        <div class="" id="toTop" style="display: none;">
            <a href="#" class="js-gotop1"><i class="fa fa-arrow-up"></i></a>
        </div>
        <main class="site-main">

        
        
<?php /**PATH C:\xampp\htdocs\labookelevila\resources\views/components/header.blade.php ENDPATH**/ ?>