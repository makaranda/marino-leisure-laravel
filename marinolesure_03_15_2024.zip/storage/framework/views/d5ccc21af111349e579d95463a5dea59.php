

        <!-- Favicons -->
    <link rel="shortcut icon" href="<?php echo e(URL::to('')); ?>/resources/images/icons/favicon.png">
    <?php echo $__env->yieldPushContent('css'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/vendors/bootstrap/bootstrap.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/vendors/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/vendors/themify-icons/themify-icons.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/vendors/linericon/style.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/vendors/magnefic-popup/magnific-popup.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/vendors/owl-carousel/owl.theme.default.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/vendors/owl-carousel/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/vendors/nice-select/nice-select.css">

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/css/style.css?v=<?php echo e(time()); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/css/mystyle.css?v=<?php echo e(time()); ?>">
    <link rel="stylesheet" href="<?php echo e(URL::to('')); ?>/resources/css/myresponsive.css?v=<?php echo e(time()); ?>">




<?php /**PATH C:\xampp\htdocs\labookelevila\resources\views/libraries/styles.blade.php ENDPATH**/ ?>